import java.util.ArrayList;
public interface Observer {
	
	abstract public void update(ArrayList<Double> arr);
}
